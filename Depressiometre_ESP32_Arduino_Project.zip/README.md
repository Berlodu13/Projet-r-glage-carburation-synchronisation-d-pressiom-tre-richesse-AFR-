# Depressiometre ESP32 Arduino Project

This repository contains the Arduino code and modules for the ESP32-based depressiometer.