// Header for AFR sensor module
#ifndef AFR_MODULE_H
#define AFR_MODULE_H
#endif